

public interface ITranslation {
	int getTx();

	int getTy();
}
